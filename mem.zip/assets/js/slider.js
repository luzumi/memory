import domMapping from './domMapping.js';

export class Slider extends HTMLElement {
    constructor(parent, options) {
        super();
        this.parent = parent;
        this.options = options;
        this.isDragging = false;
        this.init();
    }

    init() {
        this.sliderContainer = domMapping.createElementDynamical(this.parent, 'div', this.options.containerClass);
        this.sliderObject = domMapping.createElementDynamical(this.sliderContainer, 'iframe', this.options.containerClass + '-iframe');
        this.sliderObject.src = 'assets/others/1412207692.svg';
        this.sliderObject.height = '70px';
        this.sliderObject.width = '70px';

        this.sliderLabel = domMapping.createElementDynamical(this.sliderObject, 'label', 'sliderLabel', this.options.labelText);
        this.sliderLabel.text = this.options.sliderId;

        let isDragging = false;

        this.sliderObject.addEventListener('load', () => {
            const iframeDocument = this.sliderObject.contentDocument;
            const circle = iframeDocument.querySelector('#circle');

            circle.addEventListener('mousedown', function(e) {
                console.log(`[${new Date().toISOString()}] Mousedown auf Circle`, isDragging);
                isDragging = true;

            }, { capture: true });
            circle.addEventListener('mousemove', function(e) {
                console.log(`[${new Date().toISOString()}] Mousemove-Event im Circle gefeuert`, isDragging);
                isDragging = true;
                if (isDragging) {
                    console.log("Mouse bewegt im iFrame");
                    console.log(e.clientX, e.clientY);
                }
            });
            circle.addEventListener('mouseup', function(e) {
                console.log(`[${new Date().toISOString()}] Mouseup auf Circle`, isDragging);
                isDragging = false;
            });


        });











        //
        // this.valueDisplay = domMapping.createElementDynamical(this.sliderContainer, 'span', 'digital-display', this.options.value.toString());
        // this.valueDisplay.id = 'digital-display-' + this.options.sliderId;
        //
        // this.sliderInput = domMapping.createElementDynamical(this.sliderContainer, 'input');
        // this.sliderInput.type = 'range';
        // this.sliderInput.id = this.options.sliderId;
        // this.sliderInput.min = this.options.min;
        // this.sliderInput.max = this.options.max;
        // this.sliderInput.step = this.options.step;
        // this.sliderInput.value = this.options.value;
        //
        // if (this.options.callback) {
        //     this.sliderInput.addEventListener('input', () => {
        //         const newValue = this.sliderInput.value;
        //         this.valueDisplay.innerHTML = newValue; // Aktualisiere das digitale Display
        //         this.options.callback(parseInt(newValue, 10));
        //     });
        // }
        //
        // this.sliderInput.addEventListener('input', () => {
        //     const value = this.sliderInput.value;
        //
        //     globalState[this.options.value] = parseInt(value, 10);
        // });
    }
}

customElements.define('my-slider', Slider);