import AnimateHeader from "./animateHeader.js";
import imagePool from "./imagePool.js";
import { globalState } from './globalState.js';
import handles from './handles.js';
import { domMapping } from './domMapping.js';