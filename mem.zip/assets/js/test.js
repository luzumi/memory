// import domMapping from './domMapping.js';
// import {globalState} from "./globalState.js";
//
// export class Slider extends HTMLElement {
//     constructor(parent, options) {
//         super();
//         this.parent = parent;
//         this.options = options;
//         this.isDragging = false;
//         this.init();
//         this.initialMarkerPosition = { x: 0, y: 0 };
//     }
//
//
//     createSliderElements() {
//         this.sliderContainer = domMapping.createElementDynamical(this.parent, 'div', this.options.containerClass);
//         this.sliderObject = domMapping.createElementDynamical(this.sliderContainer, 'object', this.options.containerClass + '-iframe');
//         this.sliderObject.data = 'assets/others/base1412207692.svg';
//         this.sliderObject.height = '70px';
//         this.sliderObject.width = '70px';
//         this.sliderLabel = domMapping.createElementDynamical(this.sliderObject, 'label', 'sliderLabel', this.options.labelText);
//         this.sliderLabel.text = this.options.sliderId;
//     }
//
//     setMarkerPosition(svgRoot, Cx, Cy, angle) {
//         const markerElement = svgRoot.querySelector("#marker25_1");
//         markerElement.setAttribute("transform", `rotate(${angle - 90},${Cx},${Cy})`);
//     }
//
//     setInitialMarkerPosition(svgRoot, Cx, Cy) {
//         const initialAngle = 330 + (this.options.value / this.options.max * 300);
//         this.initialMarkerAngle = initialAngle;  // Speichern des initialen Winkels
//         this.setMarkerPosition(svgRoot, Cx, Cy, initialAngle);
//     }
//
//
//     setupEventListeners(svgRoot, Cx, Cy, R) {
//         const self = this;
//         svgRoot.addEventListener('mousedown', function (e) {
//             this.isDragging = true;
//
//             console.log("Mousedown- SliderMax: ", self.options.max);
//             // Neuen SVG-Punkt erstellen
//             const point = svgRoot.createSVGPoint();
//             // Client-Koordinaten des Events speichern
//             point.x = e.clientX;
//             point.y = e.clientY;
//
//             // Aktuelle Transformation des SVG-Elements abrufen
//             const ctm = svgRoot.getScreenCTM();
//             // Inverse Transformation berechnen
//             const inverseCTM = ctm.inverse();
//
//             // Lokale Koordinaten im SVG-Element berechnen
//             const localPoint = point.matrixTransform(inverseCTM);
//
//             // Differenz zwischen lokalem Punkt und Zentrum berechnen
//             const dx = localPoint.x - Cx;
//             const dy = localPoint.y - Cy;
//
//             // Winkel in Bogenmaß berechnen
//             let angle = Math.atan2(dy, dx);
//             let angleDeg = (angle * 180 / Math.PI + 270) % 360;
//             console.log("Unangepasster Winkel:", angle, angleDeg);
//
//             // Anzahl der Sektoren und Winkel pro Sektor berechnen
//             // Anzahl der Sektoren und Winkel pro Sektor berechnen
//             const numSectors = self.options.max;  // Wenn max 3 ist, dann haben wir 3 Sektoren
//             const anglePerSector = 225 / numSectors;  // Max Theta ist 260
//
// // Ausgewählten Sektor und Wert berechnen
//             // Toleranz hinzufügen
//             const tolerance = 5; // 5 Grad Toleranz
//             let selectedSector = Math.floor((angleDeg + tolerance) / anglePerSector);
//             if (selectedSector >= numSectors) {
//                 selectedSector = 0;
//             }
//             const selectedValue = selectedSector + 1;  // Ausgewählter Wert ist Sektor + 1
//
// // Angepasster Winkel
//             const adjustedAngle = selectedValue * anglePerSector;
//             console.log("Angepasster Winkel:", adjustedAngle)
// // Eingeschränkter Winkel
//             const constrainedTheta = 225 + (selectedValue * adjustedAngle);  // Max Theta ist 260
//             // const constrainedTheta = Math.min(300, adjustedAngle);  // Max Theta ist 260
//
//             console.log("Eingeschränkter Winkel:", 225 + (selectedValue * adjustedAngle));
//
//             // Markerposition setzen
//             self.setMarkerPosition(svgRoot, Cx, Cy, constrainedTheta);
//
//             // Debug-Ausgabe
//             globalState[`${self.options.value}`] = selectedValue;
//             console.log("GlobalState: ", globalState[`${self.options.value}`]);
//             console.log(selectedValue + self.options.step, selectedSector, constrainedTheta );
//         });
//
//         svgRoot.addEventListener('mousemove', function (e) {
//         });
//
//         svgRoot.addEventListener('mouseup', function (e) {
//             this.isDragging = false;
//         });
//     }
//
//     addLinesToSVG(svgRoot, Cx, Cy, R) {
//         const startTheta = 225 * Math.PI / 180;
//         const endTheta = 310 * Math.PI / 180;
//         for (let i = 0; i < this.options.max; i++) {
//             const ratio = i / (this.options.max - 1);
//             const theta = startTheta + ratio * (endTheta - startTheta);
//
//             const x1 = Cx + R * Math.cos(theta);
//             const y1 = Cy + R * Math.sin(theta);
//
//             const x2 = Cx + (R + 200) * Math.cos(theta);
//             const y2 = Cy + (R + 200) * Math.sin(theta);
//
//             const lineElement = document.createElementNS("http://www.w3.org/2000/svg", "line");
//             lineElement.setAttribute("x1", `${x1}`);
//             lineElement.setAttribute("y1", `${y1}`);
//             lineElement.setAttribute("x2", `${x2}`);
//             lineElement.setAttribute("y2", `${y2}`);
//             lineElement.setAttribute("class", "fil0 str2");
//             svgRoot.appendChild(lineElement);
//         }
//     }
//
//
//     init() {
//         this.createSliderElements();
//         this.sliderObject.addEventListener('load', () => {
//             const svgDoc = this.sliderObject.contentDocument;
//             const svgRoot = svgDoc.documentElement;
//             const circleElement = svgRoot.querySelector("#circle61");
//
//             const Cx = parseFloat(circleElement.getAttribute('cx'));
//             const Cy = parseFloat(circleElement.getAttribute('cy'));
//             const R = 7500;  // Radius, an dem die Linien und Pfeile positioniert werden sollen
//
//             this.addLinesToSVG(svgRoot, Cx, Cy, R);
//             this.setupEventListeners(svgRoot, Cx, Cy, R);
//             this.setInitialMarkerPosition(svgRoot, Cx, Cy);
//         });
//     }
// }
//
// customElements.define('my-slider', Slider);